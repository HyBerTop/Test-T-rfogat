/*
* File: testterfogat.java
* Author: Róth József
* Copyright: 2023, Róth József
* Group: Szoft/I/1
* Date: 2023-04-04
* Github: https://github.com/HyBerTop/
* Licenc: GNU GPL
*/

import java.util.Scanner;

public class testterfogat {
  static float calcuateAreaOfCube(float side) {
    
    return side;

  }

  public static void main(String[] args) {
    Scanner SC = new Scanner(System.in);
    
    System.out.printf("Róth József, I/1/N, 2023.04.04");
    
    int a=8; 
    float d = 0;
    float result1=0;
    float result2=0;

    System.out.printf("Adja meg a kocka lapátlóját: ");
    d = SC.nextFloat();

    result1 = d * d * d;
    result2 = result1 / a;

    System.out.printf("A kocka térfogata: %f\n", result2);
  }
}